const Book = require('../models/book');

function booksIndex(req, res) {
  Book.find((err, books) => {
    if(err) return res.status(500).json({ error: err });
    return res.json(books);
  });
}

function booksCreate(req, res) {
  Book.create(req.body, (err, user) => {
    if(err) return res.status(400).json({ error: err });
    return res.json(user);
  });
}

function booksShow(req, res) {
  Book.findById(req.params.id, (err, user) => {
    if(err) return res.status(500).json({ error: err });
    if(!user) return res.status(404).json({ error: 'Not found' });
    return res.json(user);
  });
}

function booksUpdate(req, res) {
  Book.findById(req.params.id, (err, user) => {
    if(err) return res.status(500).json({ error: err });
    if(!user) return res.status(404).json({ error: 'Not found' });

    for(const key in req.body) {
      user[key] = req.body[key];
    }

    user.save((err, user) => {
      if(err) return res.status(400).json({ error: err });
      res.json(user);
    });
  });
}

function booksDelete(req, res) {
  Book.findById(req.params.id, (err, user) => {
    if(err) return res.status(500).json({ error: err });
    if(!user) return res.status(404).json({ error: 'Not found' });

    user.remove(err => {
      if(err) return res.status(500).json({ error: err });
      res.status(204).send();
    });
  });
}

module.exports = {
  index: booksIndex,
  create: booksCreate,
  show: booksShow,
  update: booksUpdate,
  delete: booksDelete
};
