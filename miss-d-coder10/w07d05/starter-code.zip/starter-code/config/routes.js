const router = require('express').Router();
const booksController = require('../controllers/books');
const authController = require('../controllers/auth');

router
  .post('/login', authController.login)
  .post('/register', authController.register);

router.route('/books')
  .get(booksController.index)
  .post(booksController.create);

router.route('/books/:id')
  .get(booksController.show)
  .put(booksController.update)
  .delete(booksController.delete);

module.exports = router;
