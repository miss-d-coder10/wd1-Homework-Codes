module.exports = {
  uri: 'mongodb://localhost/restful-angular-homework'
};
