module.exports = {
  secret: 'This is baller'
};