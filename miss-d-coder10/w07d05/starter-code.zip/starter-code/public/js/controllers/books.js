angular.module('bookApp')
  .controller('BooksIndexController', BooksIndexController);

BooksIndexController.$inject = ['Book'];

function BooksIndexController (Book){
  const BooksIndex = this;

  BooksIndex.all = Book.query();
}
