angular
  .module('bookApp', ['ngResource', 'ui.router'])
  .config(Router);

Router.$inject = ['$stateProvider', '$urlRouterProvider'];

function Router($stateProvider, $urlRouterProvider){
  $stateProvider
    .state('booksIndex', {
      url: '/books',
      templateUrl: '/templates/booksIndex.html',
      controller: 'BooksIndexController as booksIndex'
    });
  $urlRouterProvider.otherwise('/books');
}
