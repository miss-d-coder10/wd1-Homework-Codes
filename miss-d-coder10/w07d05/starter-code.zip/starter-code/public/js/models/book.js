angular.module('bookApp')
  .factory('Book', Book);

// Film.$inject = ['$resource'];
function Book($resource) {
  return new $resource('/films/:id', { id: '@_id' }, {
    update: {method: 'PUT'}
  });
}
